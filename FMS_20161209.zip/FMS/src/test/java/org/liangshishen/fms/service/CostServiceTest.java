package org.liangshishen.fms.service;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.liangshishen.fms.common.Pager;
import org.liangshishen.fms.model.Cost;
import org.liangshishen.fms.param.QueryParam;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.servlet.tags.Param;

import javax.annotation.Resource;

import static org.junit.Assert.*;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("classpath*:spring-mybatis.xml")
public class CostServiceTest {

	@Resource
	private CostService costService;

	@Test
	public void findPager() throws Exception {
		QueryParam param = new QueryParam(1, 3, "id desc");
		Pager<Cost> pager = costService.findPager(param);
		System.out.println(pager.getPageNumber() + ", " +
				pager.getPageSize() + ", " +
				pager.getTotalRow() + ", " +
				pager.getTotalPage());
		for (Cost cost : pager.getList()) {
			System.out.println(cost.getId() + "," + cost.getName() + "," + cost.getCreateTime());
		}
	}
}