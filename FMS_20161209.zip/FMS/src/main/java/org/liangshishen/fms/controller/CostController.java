package org.liangshishen.fms.controller;

import org.liangshishen.fms.common.JsonResult;
import org.liangshishen.fms.common.Pager;
import org.liangshishen.fms.model.Cost;
import org.liangshishen.fms.param.QueryParam;
import org.liangshishen.fms.service.CostService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;

@Controller
@RequestMapping("/cost")
public class CostController {

	@Resource
	private CostService costService;

	// 转发到资费列表页面
	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public String list(QueryParam param, Model model) {
		Pager<Cost> pager = costService.findPager(param);
		model.addAttribute("pager", pager);
		return "cost/cost_list";
	}

	// 转发到详细资费页面
	@RequestMapping(value = "/detail/{id}", method = RequestMethod.GET)
	public String detail(@PathVariable("id") int id, Model model) {
		Cost cost = costService.findById(id);
		model.addAttribute("cost", cost);
		return "cost/cost_detail";
	}

	// 转发到新增资费页面
	@RequestMapping(value = "/add", method = RequestMethod.GET)
	public String add() {
		return "cost/cost_add";
	}

	// 新增资费
	@RequestMapping(value = "/add", method = RequestMethod.POST)
	@ResponseBody
	public JsonResult add(Cost cost) {
		costService.save(cost);
		return JsonResult.ok();
	}

	// 转发到修改资费页面
	@RequestMapping(value = "/update/{id}", method = RequestMethod.GET)
	public String update(@PathVariable("id") int id, Model model) {
		Cost cost = costService.findById(id);
		model.addAttribute("cost", cost);
		return "cost/cost_update";
	}

	// 修改资费
	@RequestMapping(value = "/update/{id}", method = RequestMethod.POST)
	@ResponseBody
	public JsonResult update(@PathVariable("id") int id, Cost cost) {
		cost.setId(id);
		costService.update(cost);
		return JsonResult.ok();
	}

	// 删除资费
	@RequestMapping(value = "/delete", method = RequestMethod.POST)
	@ResponseBody
	public JsonResult delete(int id) {
		costService.delete(id);
		return JsonResult.ok();
	}

	// 启动资费
	@RequestMapping(value = "/start", method = RequestMethod.POST)
	@ResponseBody
	public JsonResult start(int id) {
		costService.start(id);
		return JsonResult.ok();
	}

	// 暂停资费
	@RequestMapping(value = "/pause", method = RequestMethod.POST)
	@ResponseBody
	public JsonResult pause(int id) {
		costService.pause(id);
		return JsonResult.ok();
	}
}
