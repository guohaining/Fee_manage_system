package org.liangshishen.fms.service;

import org.liangshishen.fms.exception.BusinessException;
import org.liangshishen.fms.mapper.AdminMapper;
import org.liangshishen.fms.model.Admin;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import javax.annotation.Resource;

@Service("adminService")
public class AdminServiceImpl implements AdminService {

	@Resource
	private AdminMapper adminMapper;

	@Override
	public Admin checkLogin(String username, String password) {
		if (StringUtils.isEmpty(username)) {
			throw new BusinessException("用户名不能为空");
		}
		if (StringUtils.isEmpty(password)) {
			throw new BusinessException("密码不能为空");
		}
		Admin admin = adminMapper.selectByUsername(username);
		if (admin == null) {
			throw new BusinessException("用户名不正确");
		}
		if (!admin.getPassword().equals(password)) {
			throw new BusinessException("密码不正确");
		}
		return admin;
	}
}
