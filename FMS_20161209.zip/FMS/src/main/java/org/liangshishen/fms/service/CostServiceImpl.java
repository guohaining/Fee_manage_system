package org.liangshishen.fms.service;

import org.liangshishen.fms.common.Pager;
import org.liangshishen.fms.exception.BusinessException;
import org.liangshishen.fms.mapper.CostMapper;
import org.liangshishen.fms.model.Cost;
import org.liangshishen.fms.param.QueryParam;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;

@Service("costService")
public class CostServiceImpl implements CostService {

	@Resource
	private CostMapper costMapper;

	@Override
	public Pager<Cost> findPager(QueryParam param) {
		List<Cost> list = costMapper.selectPager(param);
		int totalRow = costMapper.selectCount();
		return new Pager<>(list, param, totalRow);
	}

	@Override
	public void save(Cost cost) {
		// TODO 检验
		if (cost != null) {
			cost.setStatus("1");
			cost.setCreateTime(new Date());
		}
		costMapper.insert(cost);
	}

	@Override
	public Cost findById(int id) {
		return costMapper.selectByPrimaryKey(id);
	}

	@Override
	public void update(Cost cost) {
		Cost target = findById(cost.getId());
		if (target == null) {
			throw new BusinessException("要修改的对象不存在");
		}
		if ("0".equals(target.getStatus())) {
			throw new BusinessException("开通后不可以修改");
		}
		target.setName(cost.getName());
		target.setCostType(cost.getCostType());
		target.setBaseDuration(cost.getBaseDuration());
		target.setBaseCost(cost.getBaseCost());
		target.setUnitCost(cost.getUnitCost());
		target.setDescr(cost.getDescr());
		costMapper.updateByPrimaryKey(target);
	}

	@Override
	public void delete(int id) {
		Cost target = findById(id);
		if (target != null && "0".equals(target.getStatus())) {
			throw new BusinessException("开通后不可以删除");
		}
		costMapper.deleteByPrimaryKey(id);
	}

	@Override
	public void start(int id) {
		Cost cost = new Cost();
		cost.setId(id);
		cost.setStatus("0");
		cost.setStartTime(new Date());
		costMapper.updateStatus(cost);
	}

	@Override
	public void pause(int id) {
//		Cost target = findById(id);
//		if (target != null && "0".equals(target.getStatus())) {
//			throw new BusinessException("开通后不可以再停用");
//		}
		Cost cost = new Cost();
		cost.setId(id);
		cost.setStatus("1");
		costMapper.updateStatus(cost);
	}
}
