package org.liangshishen.fms.controller;

import org.liangshishen.fms.common.CaptchaUtils;
import org.liangshishen.fms.common.JsonResult;
import org.liangshishen.fms.model.Admin;
import org.liangshishen.fms.service.AdminService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import javax.imageio.ImageIO;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.Map;

@Controller
public class LoginController {

	@Resource
	private AdminService adminService;

	// 转发到登录页面
	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public String login() {
		return "login";
	}

	// 登录处理
	@RequestMapping(value = "/login", method = RequestMethod.POST)
	@ResponseBody
	public JsonResult login(HttpSession session, String username, String password, String captcha) {
		String vCode = (String) session.getAttribute(CaptchaUtils.CAPTCHA_NAME);
		if (captcha == null || !captcha.equalsIgnoreCase(vCode)) {
			return JsonResult.error("验证码错误");
		}
		Admin admin = adminService.checkLogin(username, password);
		session.setAttribute("loginedAdmin", admin);
		return JsonResult.ok();
	}

	// 生成验证码
	@RequestMapping(value = "/captcha", method = RequestMethod.GET)
	public void captcha(HttpSession session, HttpServletResponse response) {
		Map<String, BufferedImage> map = CaptchaUtils.generateCaptcha();
		String vCode = map.keySet().iterator().next();
		session.setAttribute(CaptchaUtils.CAPTCHA_NAME, vCode);
		response.setHeader("Pragma", "no-cache");
		response.setHeader("Cache-Control", "no-cache");
		response.setDateHeader("Expires", 0);
		response.setContentType("image/jpeg");
		ServletOutputStream sos = null;
		try {
			sos = response.getOutputStream();
			ImageIO.write(map.get(vCode), "jpeg", sos);
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (sos != null) try {
				sos.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

}
