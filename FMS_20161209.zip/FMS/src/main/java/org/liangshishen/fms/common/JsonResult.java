package org.liangshishen.fms.common;

import java.io.Serializable;

public class JsonResult implements Serializable {

	private static final long serialVersionUID = -7446694649139750260L;

	private String status;
	private String message;

	private static final String STATUS_SUCCESS = "success";
	private static final String STATUS_ERROR = "error";

	public JsonResult() {
	}

	public JsonResult(String status, String message) {
		this.status = status;
		this.message = message;
	}

	public static JsonResult ok() {
		return ok(null);
	}

	public static JsonResult ok(String message) {
		return new JsonResult(STATUS_SUCCESS, message);
	}

	public static JsonResult error(String message) {
		return new JsonResult(STATUS_ERROR, message);
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
}
