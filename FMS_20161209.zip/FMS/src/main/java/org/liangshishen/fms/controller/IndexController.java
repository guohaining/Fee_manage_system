package org.liangshishen.fms.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class IndexController {

	// 转发到主页
	@RequestMapping("/index")
	public String index() {
		return "index";
	}
}
