package org.liangshishen.fms.exception;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.liangshishen.fms.common.JsonResult;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.SimpleMappingExceptionResolver;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

/**
 * 混合(JSP+JSON)的简单映射异常解析器
 * Created by LiangShiShen on 2016/12/9.
 */
public class MixedSimpleMappingExceptionResolver extends SimpleMappingExceptionResolver {

	@Override
	protected ModelAndView doResolveException(
			HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) {
		HandlerMethod method = (HandlerMethod) handler;
		ResponseBody responseBody = method.getMethodAnnotation(ResponseBody.class);
		// 返回默认视图
		if (responseBody == null) {
			return super.doResolveException(request, response, handler, ex);
		}
		// 返回JSON格式
		// response.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
		response.setContentType(MediaType.APPLICATION_JSON_VALUE);
		response.setCharacterEncoding("UTF-8");
		try {
			PrintWriter writer = response.getWriter();
			String json = new ObjectMapper().writeValueAsString(JsonResult.error(ex.getMessage()));
			writer.write(json);
			writer.flush();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return new ModelAndView();
	}

	private boolean isAjaxRequest(HttpServletRequest request) {
		return "XMLHttpRequest".equalsIgnoreCase(request.getHeader("X-Requested-With"))
				|| request.getHeader("accept").contains("application/json");
	}
}
