package org.liangshishen.fms.mapper;

import org.liangshishen.fms.model.Cost;
import org.liangshishen.fms.param.QueryParam;

import java.util.List;

public interface CostMapper {

	List<Cost> selectPager(QueryParam param);

	int selectCount();

	int deleteByPrimaryKey(Integer id);

	int insert(Cost cost);

	Cost selectByPrimaryKey(Integer id);

	int updateByPrimaryKey(Cost cost);

	int updateStatus(Cost cost);
}