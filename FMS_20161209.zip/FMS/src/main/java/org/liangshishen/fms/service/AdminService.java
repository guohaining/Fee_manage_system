package org.liangshishen.fms.service;

import org.liangshishen.fms.model.Admin;

public interface AdminService {

	Admin checkLogin(String username, String password);
}
