package org.liangshishen.fms.common;

import org.liangshishen.fms.param.QueryParam;

import java.io.Serializable;
import java.util.List;

public class Pager<T> implements Serializable {

	private static final long serialVersionUID = 6817807404946724632L;

	// 数据列表
	private List<T> list;
	// 当前页码
	private int pageNumber;
	// 每页显示的大小
	private int pageSize;
	// 总记录数
	private int totalRow;
	// 总页数
	private int totalPage;

	public Pager(List<T> list, int pageNumber, int pageSize, int totalRow) {
		this.list = list;
		this.pageNumber = pageNumber;
		this.pageSize = pageSize;
		this.totalRow = totalRow;
		calcTotalPage();
	}

	public Pager(List<T> list, QueryParam queryParam, int totalRow) {
		this(list, queryParam.getPageNumber(), queryParam.getPageSize(), totalRow);
	}

	private void calcTotalPage() {
		this.totalPage = (int) Math.ceil((double) totalRow / pageSize);
	}

	public List<T> getList() {
		return list;
	}

	public int getPageNumber() {
		return pageNumber;
	}

	public int getPageSize() {
		return pageSize;
	}

	public int getTotalRow() {
		return totalRow;
	}

	public int getTotalPage() {
		return totalPage;
	}

	public boolean isFirstPage() {
		return pageNumber == 1;
	}

	public boolean isLastPage() {
		return pageNumber == totalPage;
	}
}
