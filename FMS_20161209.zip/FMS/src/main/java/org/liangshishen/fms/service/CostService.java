package org.liangshishen.fms.service;

import org.liangshishen.fms.common.Pager;
import org.liangshishen.fms.model.Cost;
import org.liangshishen.fms.param.QueryParam;

public interface CostService {

	Pager<Cost> findPager(QueryParam param);

	void save(Cost cost);

	Cost findById(int id);

	void update(Cost cost);

	void delete(int id);

	void start(int id);

	void pause(int id);
}
