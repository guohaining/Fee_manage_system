package org.liangshishen.fms.param;

import java.io.Serializable;

public class QueryParam implements Serializable {

	private static final long serialVersionUID = 6937032808009216776L;

	private int pageNumber;
	private int pageSize;
	private String orderBy;

	public QueryParam() {
		this.pageNumber = 1;
		this.pageSize = 8;
	}

	public QueryParam(int pageNumber, int pageSize, String orderBy) {
		this.pageNumber = pageNumber;
		this.pageSize = pageSize;
		this.orderBy = orderBy;
	}

	public int getOffset() {
		return (pageNumber - 1) * pageSize;
	}

	public int getPageNumber() {
		return pageNumber;
	}

	public void setPageNumber(int pageNumber) {
		this.pageNumber = pageNumber;
	}

	public int getPageSize() {
		return pageSize;
	}

	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}

	public String getOrderBy() {
		return orderBy;
	}

	public void setOrderBy(String orderBy) {
		this.orderBy = orderBy;
	}
}
