package org.liangshishen.fms.mapper;

import org.liangshishen.fms.model.Admin;

public interface AdminMapper {
	int deleteByPrimaryKey(Integer id);

	int insert(Admin record);

	Admin selectByPrimaryKey(Integer id);

	int updateByPrimaryKey(Admin record);

	Admin selectByUsername(String username);
}