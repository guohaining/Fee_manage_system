-- ----------------------------
-- FMS 资费管理系统数据库
-- ----------------------------
drop database if exists db_fms;
create database db_fms default character set utf8;
use db_fms;

-- ----------------------------
-- 管理员信息表
-- ----------------------------
DROP TABLE IF EXISTS admin;
CREATE TABLE admin (
  id int(11) PRIMARY KEY AUTO_INCREMENT,
  username varchar(64),
  password varchar(64),
  name varchar(64),
  phone varchar(32),
  email varchar(128),
  create_time datetime
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of admin
-- ----------------------------
INSERT INTO admin VALUES ('1', 'admin', '123', '管理员', '123456789', 'admin@tarena.com.cn', '2015-10-17');
INSERT INTO admin VALUES ('2', 'zhangfei', '123', '张飞', '123456789', 'zhangfei@tarena.com.cn', '2015-10-17');
INSERT INTO admin VALUES ('3', 'liubei', '123', '刘备', '123456789', 'liubei@tarena.com.cn', '2015-10-17');
INSERT INTO admin VALUES ('4', 'caocao', '123', '曹操', '123456789', 'caocao@tarena.com.cn', '2015-10-17');
INSERT INTO admin VALUES ('5', 'aaa', '123', 'AAA', '123456789', 'aaa@tarena.com.cn', '2015-10-17');
INSERT INTO admin VALUES ('6', 'bbb', '123', 'BBB', '123456789', 'bbb@tarena.com.cn', '2015-10-17');

-- ----------------------------
-- 角色信息表
-- ----------------------------
DROP TABLE IF EXISTS role;
CREATE TABLE role (
  id int(11) PRIMARY KEY AUTO_INCREMENT,
  name varchar(64)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of role
-- ----------------------------
INSERT INTO role VALUES ('1', '管理员');
INSERT INTO role VALUES ('2', '经理');
INSERT INTO role VALUES ('3', '营业员');
INSERT INTO role VALUES ('4', 'aaa');
INSERT INTO role VALUES ('5', 'bbb');
INSERT INTO role VALUES ('6', 'ccc');

-- ----------------------------
-- 管理员与角色关联表
-- ----------------------------
DROP TABLE IF EXISTS admin_role;
CREATE TABLE admin_role (
  admin_id int(11),
  role_id int(11)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of admin_role
-- ----------------------------
INSERT INTO admin_role VALUES ('1', '1');
INSERT INTO admin_role VALUES ('1', '2');
INSERT INTO admin_role VALUES ('2', '3');
INSERT INTO admin_role VALUES ('2', '4');
INSERT INTO admin_role VALUES ('3', '5');
INSERT INTO admin_role VALUES ('3', '6');

-- ----------------------------
-- 模块信息表
-- ----------------------------
DROP TABLE IF EXISTS module;
CREATE TABLE module (
  id int(11) PRIMARY KEY AUTO_INCREMENT,
  name varchar(64)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of module
-- ----------------------------
INSERT INTO module VALUES ('1', '角色管理');
INSERT INTO module VALUES ('2', '管理员');
INSERT INTO module VALUES ('3', '资费管理');
INSERT INTO module VALUES ('4', '账务账号');
INSERT INTO module VALUES ('5', '业务账号');
INSERT INTO module VALUES ('6', '账单管理');
INSERT INTO module VALUES ('7', '报表');

-- ----------------------------
-- 角色与模块关联表
-- ----------------------------
DROP TABLE IF EXISTS role_module;
CREATE TABLE role_module (
  role_id int(11),
  module_id int(11)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of role_module
-- ----------------------------
INSERT INTO role_module VALUES ('1', '1');
INSERT INTO role_module VALUES ('1', '2');
INSERT INTO role_module VALUES ('2', '3');
INSERT INTO role_module VALUES ('2', '4');
INSERT INTO role_module VALUES ('3', '5');
INSERT INTO role_module VALUES ('3', '6');

-- ----------------------------
-- 功能信息表
-- ----------------------------
DROP TABLE IF EXISTS function;
CREATE TABLE function (
  id int(11) PRIMARY KEY AUTO_INCREMENT,
  module_id int(11),
  code varchar(64),
  name varchar(64),
  url varchar(128)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of function_info
-- ----------------------------

-- ----------------------------
-- 资费信息表
-- ----------------------------
DROP TABLE IF EXISTS cost;
CREATE TABLE cost (
  id int(11) PRIMARY KEY AUTO_INCREMENT,
  name varchar(64),
  base_duration int(11),
  base_cost double(7,2),
  unit_cost double(7,2),
  status char(1),
  descr varchar(128),
  create_time datetime,
  start_time datetime,
  cost_type char(1)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of cost
-- ----------------------------
INSERT INTO cost VALUES ('1', '5.9元套餐', '20', '5.9', '0.4', '0', '5.9元20小时/月,超出部分0.4元/时', null, null, null);
INSERT INTO cost VALUES ('2', '6.9元套餐', '40', '6.9', '0.3', '0', '6.9元40小时/月,超出部分0.3元/时', null, null, '2');
INSERT INTO cost VALUES ('3', '8.5元套餐', '100', '8.5', '0.2', '0', '8.5元100小时/月,超出部分0.2元/时', null, null, null);
INSERT INTO cost VALUES ('4', '10.5元套餐', '200', '10.5', '0.1', '0', '10.5元200小时/月,超出部分0.1元/时', null, null, null);
INSERT INTO cost VALUES ('5', '计时收费', null, null, '0.5', '0', '0.5元/时,不使用不收费', null, null, null);
INSERT INTO cost VALUES ('6', '包月', null, '20', null, '0', '每月20元,不限制使用时间', null, null, null);
INSERT INTO cost VALUES ('7', '30元套餐', '150', '30', '0.2', null, '30元套餐包150小时，0.2元/小时。', null, null, '2');
INSERT INTO cost VALUES ('8', '包月2', null, '36', null, '0', '每月36元套餐。', '2014-10-10 09:25:17', null, '1');
INSERT INTO cost VALUES ('9', '58元套餐', '290', '58', '0.2', '0', '58元套餐包290小时,0.2元/小时', '2014-10-10 16:03:56', null, '2');
INSERT INTO cost VALUES ('10', '88元套餐', '400', '88', '0.3', '0', '88元套餐包400个小时,超出部分0.3元/小时', '2014-10-10 17:19:14', null, '2');
INSERT INTO cost VALUES ('11', '包月3', null, '36', null, '1', '36元包月', '2014-10-10 17:20:17', '2014-10-11 16:05:50', '1');

-- ----------------------------
-- 账务信息表
-- ----------------------------
DROP TABLE IF EXISTS account;
CREATE TABLE account (
  id int(11) PRIMARY KEY AUTO_INCREMENT,
  recommender_id int(11),
  login_name varchar(64),
  login_password varchar(64),
  real_name varchar(64),
  idcard_no char(18),
  birthdate date,
  gender char(1),
  occupation varchar(64),
  phone varchar(32),
  email varchar(128),
  mail_address varchar(255),
  zipcode char(6),
  qq varchar(15),
  status char(1),
  create_time datetime,
  pause_time datetime,
  close_time datetime,
  last_login_time datetime,
  last_login_ip varchar(16)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of account
-- ----------------------------
INSERT INTO account VALUES ('1', null, 'taiji001', '256528', 'zhangsanfeng', '410381194302256528', '1943-02-25', null, null, '13669351234', null, null, null, null, '0', '2014-08-08 08:08:08', null, null, null, null);
INSERT INTO account VALUES ('2', null, 'xl18z60', '190613', 'guojing', '330682196903190613', '1969-03-19', null, null, '13338924567', null, null, null, null, '0', '2014-08-08 08:08:08', null, null, null, null);
INSERT INTO account VALUES ('3', '1', 'dgbf70', '270429', 'huangrong', '330902197108270429', '1971-08-27', null, null, '13637811357', null, null, null, null, '0', '2014-08-08 08:08:08', null, null, null, null);
INSERT INTO account VALUES ('4', '5', 'mjjzh64', '041115', 'zhangwuji', '610121198906041115', '1989-06-04', null, null, '13572952468', null, null, null, null, '0', '2014-08-08 08:08:08', null, null, null, null);
INSERT INTO account VALUES ('5', '1', 'jmdxj00', '010322', 'guofurong', '350581200201010322', '1996-01-01', null, null, '18617832562', null, null, null, null, '0', '2014-08-08 08:08:08', null, null, null, null);
INSERT INTO account VALUES ('6', '2', 'ljxj90', '310346', 'luwushuang', '320211199307310346', '1993-07-31', null, null, '13186454984', null, null, null, null, '0', '2014-08-08 08:08:08', null, null, null, null);
INSERT INTO account VALUES ('7', null, 'kxhxd20', '012115', 'weixiaobao', '321022200010012115', '2000-10-01', null, null, '13953410078', null, null, null, null, '0', '2014-08-08 08:08:08', null, null, null, null);
INSERT INTO account VALUES ('8', null, 'kitty', '123123', 'maomi', '450881199007021233', '1990-07-02', null, null, '155788894732', null, null, null, null, '0', '2014-08-08 08:08:08', null, null, null, null);
INSERT INTO account VALUES ('9', null, 'panda', '123123', 'xiongmao', '450881199007021234', '1990-07-02', null, null, '155788894732', null, null, null, null, '0', '2014-08-08 08:08:08', null, null, null, null);
INSERT INTO account VALUES ('10', null, 'tiger', '123123', 'laohu', '450881199007021235', '1990-07-02', null, null, '155788894732', null, null, null, null, '0', '2014-08-08 08:08:08', null, null, null, null);
INSERT INTO account VALUES ('11', null, 'marry', '123123', 'mali', '450881199007021236', '1990-07-02', null, null, '155788890036', null, null, null, null, '0', '2014-08-08 08:08:08', null, null, null, null);

-- ----------------------------
-- UNIX服务器信息表
-- ----------------------------
DROP TABLE IF EXISTS host;
CREATE TABLE host (
  host_id varchar(16) PRIMARY KEY,
  name varchar(64),
  location varchar(128)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of host
-- ----------------------------
INSERT INTO host VALUES ('192.168.0.20', 'sun-server', 'beijing');
INSERT INTO host VALUES ('192.168.0.200', 'ultra10', 'beijing');
INSERT INTO host VALUES ('192.168.0.23', 'sun280', 'beijing');
INSERT INTO host VALUES ('192.168.0.26', 'sunv210', 'beijing');

-- ----------------------------
-- 业务信息表
-- ----------------------------
DROP TABLE IF EXISTS service;
CREATE TABLE service (
  id int(11) PRIMARY KEY AUTO_INCREMENT,
  account_id int(11),
  unix_host varchar(16),
  os_username varchar(64),
  login_password varchar(64),
  status char(1),
  create_date datetime,
  pause_date datetime,
  close_date datetime,
  cost_id int(11)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of service
-- ----------------------------
INSERT INTO service VALUES ('2', '1', '192.168.0.26', 'guojing', 'guo1234', '0', '2009-03-10 10:00:00', null, null, '1');
INSERT INTO service VALUES ('3', '2', '192.168.0.26', 'huangr', 'huang234', '0', '2009-03-01 15:30:05', null, null, '1');
INSERT INTO service VALUES ('4', '2', '192.168.0.20', 'huangr', 'huang234', '0', '2009-03-01 15:30:10', null, null, '3');
INSERT INTO service VALUES ('5', '2', '192.168.0.23', 'huangr', 'huang234', '0', '2009-03-01 15:30:15', null, null, '6');
INSERT INTO service VALUES ('6', '3', '192.168.0.26', 'luwsh', 'luwu2345', '0', '2012-02-10 23:50:55', null, null, '4');
INSERT INTO service VALUES ('7', '3', '192.168.0.20', 'luwsh', 'luwu2345', '0', '2012-02-10 00:00:00', null, null, '5');
INSERT INTO service VALUES ('8', '4', '192.168.0.20', 'weixb', 'wei12345', '0', '2012-02-10 11:05:20', null, null, '6');
INSERT INTO service VALUES ('9', '5', '192.168.0.20', 'guojing', 'guo09876', '0', '2012-02-11 12:05:21', null, null, '6');
INSERT INTO service VALUES ('10', '5', '192.168.0.23', 'guojing', 'guo09876', '0', '2012-02-11 12:05:21', null, null, '6');

-- ----------------------------
-- 业务详单表
-- ----------------------------
DROP TABLE IF EXISTS service_detail;
CREATE TABLE service_detail (
  id int(11) PRIMARY KEY AUTO_INCREMENT,
  service_id int(11),
  client_host varchar(16),
  os_username varchar(8),
  pid int(11),
  login_time datetime,
  logout_time datetime,
  duration double(20,9),
  cost double(20,6)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of service_detail
-- ----------------------------
INSERT INTO service_detail VALUES ('1', '2', '192.168.172.4', 'guojing', null, null, '2013-06-11 08:30:00', '3610.000000000', null);
INSERT INTO service_detail VALUES ('2', '2', '192.168.172.4', 'guojing', null, null, '2013-06-13 20:30:00', '10800.000000000', null);
INSERT INTO service_detail VALUES ('3', '2', '192.168.172.4', 'guojing', null, null, '2013-06-14 20:30:00', '10800.000000000', null);
INSERT INTO service_detail VALUES ('4', '2', '192.168.172.4', 'guojing', null, null, '2013-06-15 19:30:00', '32400.000000000', null);
INSERT INTO service_detail VALUES ('5', '2', '192.168.172.4', 'guojing', null, null, '2013-06-18 19:30:00', '36000.000000000', null);
INSERT INTO service_detail VALUES ('6', '2', '192.168.172.4', 'guojing', null, null, '2013-06-20 21:30:00', '36000.000000000', null);

-- ----------------------------
-- 账单信息表
-- ----------------------------
DROP TABLE IF EXISTS bill;
CREATE TABLE bill (
  id int(11) PRIMARY KEY AUTO_INCREMENT,
  account_id int(11),
  bill_month char(6),
  cost double(13,2),
  payment_mode char(1),
  pay_state char(10)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of bill
-- ----------------------------

-- ----------------------------
-- 账单条目表
-- ----------------------------
DROP TABLE IF EXISTS bill_item;
CREATE TABLE bill_item (
  id int(11) PRIMARY KEY AUTO_INCREMENT,
  bill_id int(11),
  service_id int(11),
  cost double(13,2)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of bill_item
-- ----------------------------
